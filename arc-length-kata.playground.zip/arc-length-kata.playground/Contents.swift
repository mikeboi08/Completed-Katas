import Foundation
func squared(number: Double)->(Double){
    
    return number * number
}

func distance(_ x1:Double, _ x2:Double, _ y1:Double, _ y2:Double ) ->(Double){
    
    var easymath = Double((squared(number: (x2-x1)) + squared(number: (y2-y1))))
    
    return sqrt(easymath)
}
func lenCurve(_ n: Int) -> Double {
    // distance formula
    
    // interval of [0,1]
    
    // break into n number of partsn
    
    var interval = 1.0/Double(n)
    var x1 = 0.0 //initializes starting point of 1
    var totalDistance = 0.0
    for x in 1...n{
        var x2 = x1 + interval
        var y1 = x1 * x1
        var y2 = x2 * x2
        totalDistance += distance(x1, x2, y1, y2)
        //calcuate distance
        //add tp totaldistance
        x1 = x2
    }
    return totalDistance
}
